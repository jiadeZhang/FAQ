#include <string.h>
#include <string.h>
#include <stdio.h>
#include <tomcrypt.h>
#include <sys/time.h>
#define BUFF_SIZE 32
#define MAX_TIMES 10000


 class ShowTime{
 public:
 	ShowTime(){
 		gettimeofday(&beg_time,NULL);
 	}
 	~ShowTime(){
 		gettimeofday(&end_time,NULL);
 		showDiff();
 	}
 	void showDiff(void){
 		int nDiff = (end_time.tv_sec-beg_time.tv_sec)*1000+(end_time.tv_usec-beg_time.tv_usec)/1000.0f;
 		printf("time:%d\n", nDiff);

 	}
 	struct timeval beg_time;
 	struct timeval end_time;

 };
int init_crypt(){

	return 0;
}
int do_job(int times){
	unsigned char key[16]={0}, IV[16]={0},buffer[BUFF_SIZE];
	symmetric_CFB ctr;
	for (int i=0; i<BUFF_SIZE; ++i){
		buffer[i]=i;
	}

	int length = BUFF_SIZE;

	int err;
	/* register twofish first */
	if (register_cipher(&twofish_desc) == -1) {
		printf("Error registering cipher.\n");
		return -1;
	}

	//int err, length=BUFF_SIZE;
	ShowTime s1;
	printf("times %d\n", times);
	for (int i=0; i<times; ++i) {
		memset(key, 0, sizeof(key));
		memset(IV, 0, sizeof(IV));

		/* somehow fill out key and IV */
		/* start up CTR mode */
		if ((err = cfb_start(
			find_cipher("twofish"), /* index of desired cipher */
			IV, /* the initial vector */
			key, /* the secret key */
			16, /* length of secret key (16 bytes) */
			16, /* 0 == default # of rounds */
			&ctr) /* where to store the CTR state */
			) != CRYPT_OK) {
				printf("ctr_start error: %s\n", error_to_string(err));
				return -1;
		}
		/* somehow fill buffer than encrypt it */
		if ((err = cfb_encrypt( buffer, /* plaintext */
			buffer, /* ciphertext */
			length, /* length of plaintext pt */
			&ctr) /* CTR state */
			) != CRYPT_OK) {
				printf("ctr_encrypt error: %s\n", error_to_string(err));
				return -1;
		}

		/* make use of ciphertext... */
		/* now we want to decrypt so let��s use ctr_setiv */
		if ((err = cfb_setiv( IV, /* the initial IV we gave to ctr_start */
			16, /* the IV is 16 bytes long */
			&ctr) /* the ctr state we wish to modify */
			) != CRYPT_OK) {
				printf("ctr_setiv error: %s\n", error_to_string(err));
				return -1;
		}
		if ((err = cfb_decrypt( buffer, /* ciphertext */
			buffer, /* plaintext */
			length, /* length of plaintext */
			&ctr) /* CTR state */
			) != CRYPT_OK) {
				printf("ctr_decrypt error: %s\n", error_to_string(err));
				return -1;
		}
	}
	/* terminate the stream */
	if ((err = cfb_done(&ctr)) != CRYPT_OK) {
		printf("ctr_done error: %s\n", error_to_string(err));
		return -1;
	}
	zeromem(key, sizeof(key));
	zeromem(&ctr, sizeof(ctr));
	return 0;

}
int main(void)
{	
	init_crypt();
	int times[]={10000/*,100000,1000000,10000000*/};
	for(int i=0; i<sizeof(times)/sizeof(int);++i)
		do_job(times[i]);
	/* clear up and return */
	return 0;
}
