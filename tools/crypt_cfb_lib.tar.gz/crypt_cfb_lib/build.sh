#!/bin/bash
g++ cfb.cpp -I./headers -L./ -ltomcrypt -o crypt
