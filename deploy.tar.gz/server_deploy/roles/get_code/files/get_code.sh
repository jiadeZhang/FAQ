#!/bin/bash
 
rsync -avz root@"{{ src_host }}":/data/app/mobpal-release/ /tmp/mobpal-release/  --delete --exclude="*.svn*" --exclude="*.log" --exclude="conf/*" --exclude="core.*"rsync -avz root@"{{ src_host }}":/data/app/mobpal-release/ /tmp/mobpal-release/  --delete --exclude="*.svn*" --exclude="*.log" --exclude="conf/*" --exclude="core.*"