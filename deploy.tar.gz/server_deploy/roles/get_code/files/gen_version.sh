#! /bin/bash

LANG=en_US.UTF-8
LUA_VERSION=$(svn info |grep -i Revision|awk '{print $2}')
SERVER_DATA_VERSION=$(svn info lua/data/ServerData |grep -i Revision|awk '{print $2}')
cat << EOF > lua/common/Version.lua
declare("GetVersion")
local LUA_VERSION = $LUA_VERSION
local SERVER_DATA_VERSION = $SERVER_DATA_VERSION
function GetVersion()
   return LUA_VERSION,SERVER_DATA_VERSION
end
EOF